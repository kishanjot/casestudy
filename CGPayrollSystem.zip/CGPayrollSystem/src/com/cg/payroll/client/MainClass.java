package com.cg.payroll.client;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDAOImpl;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
public class MainClass {
public static void main(String[] args) {
		PayrollServices services=new PayrollServicesImpl();
		/*String firstName, String lastName, String emailId, String department,
		String designation, String pancard, int yearlyInvestmentUnder80C, int basicSalary, int epf, int companyPf,
		int accountNumber, String bankName, String ifscCode)*/
		int associateId1=services.acceptAssociateDetails("Kishanjot", "Singh", "kishanjot@gmail.com" ,"TA", "Analyst", "PAC",22000, 30000, 1400, 1800, 4578, "CItiBank", "CITI0000005");
		//int associateId2=services.acceptAssociateDetails("Honey", "Singh", "Honey@gmail.com" ,"XYZ", "CEO", "AB001", 7000, 35000, 1000, 1090, 3450, "RBI", "RBI001");
		System.out.println("Associate Id 1:- "+associateId1);
	//	System.out.println("Associate Id 2:- "+associateId2);
		System.out.println(services.getAllAssociatesDetails());
	     services.calculateNetSalary(101);
		System.out.println(services.getAssociateDetails(101));
	}
}
