
public class Program1 {
	public static void main(String[] args)
	{
		Person anubhav1= new Person("null","Anubhav",'M',21,89.5F);
	}

}
