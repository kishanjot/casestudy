
public class PersonMain {

	public static void main(String[] args) {
		Person p= new Person("Anubhav","Tandon",'M',21,70.0f);
		System.out.println("Person Details:");
		System.out.println("_______________");
		System.out.println(" ");
		
		p.dispInfo();
		
		
	}

}
