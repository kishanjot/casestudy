
public class CurrentAccount extends Account {
	double overDraftLimit=10000;
	public CurrentAccount(long accNum, double balance, Person accHolder)
	{
		super( accNum,  balance,  accHolder);
	}
	
	@Override
	public void withdraw(double dep) {
		if((dep <= overDraftLimit)){
			
			this.balance-=dep;
		}
		else{
			System.out.println("Enter Ammount less than 10000");
		}
	
	}
	
	
	

}
