
public class PhnNoMain {

	public static void main(String[] args) {
		PersonClass ph= new PersonClass("Anubhav","Tandon",'M',21,70.5f);
		PersonClass mm= new PhoneNum("Anubhav","Tandon",'M',21,70.5f,9878556600L);
	
	((PhoneNum)mm).dispInfoNum();
		

	}

}
