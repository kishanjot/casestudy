package com.cg.banking.services;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.AccountDAOImpl;
import com.cg.banking.daoservices.TransactionDAOImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

public class BankingServicesImpl implements BankingServices{
	AccountDAOImpl daoImpl=new AccountDAOImpl();
	TransactionDAOImpl tDaoImpl=new TransactionDAOImpl();
     Transaction transaction;
	Account account;
	Account account1;
	public static HashMap<Integer,Transaction> transactions;

	@Override
	public Account openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		if (initBalance<500)
				throw new InvalidAmountException("Deposit amount greater than 500");
			if ((accountType.equalsIgnoreCase("Savings")) || (accountType.equals("current")))
			{
			account=new Account(accountType,initBalance);
			daoImpl.save(account);
			}
			else
				throw new InvalidAccountTypeException("Invalid type");
			return account;
		}
	

	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		Account account=daoImpl.findOne((int) accountNo);
		if(account==null)
			throw new AccountNotFoundException("Account not found");
		else{
		account.setAccountBalance(account.getAccountBalance()+amount);
		 transaction=new Transaction(amount,"Deposit");
		transaction=tDaoImpl.save(transaction);
		 account.transactions.put(transaction.getTransactionId(), transaction);
               }
return amount;
	}

	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) throws InsufficientAmountException,
			AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		account=daoImpl.findOne((int) accountNo);
		if(account.getPinNumber()==pinNumber){
		if(amount>account.getAccountBalance())
			throw new InsufficientAmountException();
		else{
		account.setAccountBalance(account.getAccountBalance()-amount);
		 transaction=new Transaction(amount,"Withdraw");
		 tDaoImpl.save(transaction);
		 account.transactions.put(transaction.getTransactionId(), transaction);
		//daoImpl.update(account);
		}
	}
		else {
			throw new InvalidPinNumberException();
			}
	  return amount;
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException,
		BankingServicesDownException, AccountBlockedException {
			account=daoImpl.findOne(accountNoFrom);
			account1=daoImpl.findOne(accountNoTo);
				if(account==null || account1==null)
				{
					throw new AccountNotFoundException("Please enter valid account number");
				}
				else {
				if(account.getPinNumber()==pinNumber)
				{
				if(transferAmount>account.getAccountBalance())
					throw new InsufficientAmountException();
				else
				account.setAccountBalance(account.getAccountBalance()-transferAmount);
				account1.setAccountBalance(account1.getAccountBalance()+transferAmount);
				 transaction=new Transaction(transferAmount,"Transfer");
				 tDaoImpl.save(transaction);
				 account.transactions.put(transaction.getTransactionId(), transaction);
				 account1.transactions.put(transaction.getTransactionId(),transaction);
				}
				else
					throw new InvalidPinNumberException();
				}
				return true;
	}


	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServicesDownException {
		account= daoImpl.findOne(accountNo);
		if(account==null){
			throw new AccountNotFoundException("No Account found");
		}
		return account;
	}


	/*public List<Account> getAllAccountDetails() throws BankingServicesDownException {
		return accountDAO.findAll();
	}*/

	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
		Account account=new Account();
		return new ArrayList<>(account.transactions.values());
	}

	@Override
	public String accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		Account account= daoImpl.findOne(accountNo);
		return account.getAccountStatus();
	}


	@Override
	public List<Account> getAllAccountDetails() throws BankingServicesDownException {
		// TODO Auto-generated method stub
		return null;
	}

}
