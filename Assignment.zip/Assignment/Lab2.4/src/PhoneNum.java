
public class PhoneNum extends PersonClass{
	
	static long phNo;
	PhoneNum(){
		
	}
	PhoneNum(String FirstName, String LastName, char Gender, int Age, float Weight,long  phNo)
	{
		super(FirstName,  LastName, Gender,Age,Weight);
		this.phNo=phNo;
					
	}
	
	public void dispInfoNum()
	{
		dispInfo();
		System.out.println("phone number"+phNo);
		
	}
	

}
