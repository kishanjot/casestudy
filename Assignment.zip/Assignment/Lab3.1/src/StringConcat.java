
public class StringConcat {
	public static void main(String []args)
	{
		String s1="Hey My name is: ";  
		String s2="Anubhav Tandon";
		System.out.println(s1);  
		  
		System.out.println(s1+s2); 
		
		System.out.println("--------------------");
		
		// Replace odd positions with #
		String s3="I Love Capgemini";
	
		char[] stringToCharArray = s3.toCharArray();
		}
		
		
	}


