public class Person {
    String fn;
    String ln;
    char gen;
    int age;
    Float weight;
    
    //---------------Zero Constructor-------------------
    
    public Person(){
        fn="";
        ln="";
        Gender gen;
        age=0;
        weight=0f;  
    }
    
    //------------Parameterized constructor----------------
    
    public Person(String fn,String ln,char gen, int age,Float weight){
        
        if(fn != null && ln != null){
            setFn(fn);
            setLn(ln);
        }
        else{
            throw new UserDefinedException("First Name and Last Name Can't Be Null");
        }
        setGen(gen);
        setAge(age);
        setWeight(weight);
        
    }
    
    //----------Getters And Setters---------------------------
    
    public String getFn() {
        return fn;
    }
    public void setFn(String fn) {
        this.fn = fn;
    }
    public String getLn() {
        return ln;
    }
    public void setLn(String ln) {
        this.ln = ln;
    }
    public char getGen() {
        return gen;
    }
    public void setGen(char gen) {
        this.gen = gen;
    }
    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }
    public Float getWeight() {
        return weight;
    }
    public void setWeight(Float weight) {
        this.weight = weight;
    }
    


    void personalDetails(){
        System.out.println("Person Details");
        System.out.println("First Name "+ getFn());
        System.out.println("Second Name "+ getLn());
        System.out.println("Gender " + getGen());
        
    }
}

