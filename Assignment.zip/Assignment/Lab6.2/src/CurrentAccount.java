public class CurrentAccount extends Account {

    public CurrentAccount(long accNo, double balance, Person accHolder) {
        super(accNo, balance, accHolder);
    }
    
    double overdraftLimit = 10000;
    
    public void withdraw(double wit){
        if(this.balance <= overdraftLimit){
            balance-=wit;
        }
        
        else{
            System.out.println("Enter Ammount Less Than 10000");
        }
    }
}