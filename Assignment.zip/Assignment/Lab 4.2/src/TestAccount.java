
public class TestAccount {
	public static void main(String [] args)
	{

		Person smith = new Person("Smith",21);
		Person kathy = new Person("Kathy",33);
		
		Account smacc = new CurrentAccount(1,12000,smith);
		Account ktacc = new SavingsAccount(2,3000,kathy);
		
		System.out.println("Smith Balance is:"+smacc.getBalance());
		System.out.println("Kathy Balance is:"+ktacc.getBalance());
		
		smacc.withdraw(11000);
		ktacc.withdraw(2600);
		
		System.out.println("Smith Balance is:"+smacc.getBalance());
		System.out.println("Kathy Balance is:"+ktacc.getBalance());

	}

}
