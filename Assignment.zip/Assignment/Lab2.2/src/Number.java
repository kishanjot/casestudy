import java.util.Scanner;
public class Number {
	public static void main(String [] args)
	{
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number to check if it is positive or negative:");
		int num=sc.nextInt();
		if (num>0)
		{
			System.out.println("Number entered is positive");
		}
		else
		{
			System.out.println("Number entered is negative");
		}
	}

}
