public class Account {

    
    long accNo;
    double balance;
    Person accHolder;
    
    public Account(long accNo, double balance, Person accHolder)
    {
        this.accNo = accNo;
        this.balance = balance;
        this.accHolder = accHolder;
    }
    
    public void deposit(double dep){
        this.balance += dep;
    }
    
    public void withdraw(double wit){
        this.balance-=wit;
    }
    
    public double getBalance(){
        return balance;
        
    }

}
