package com.cg.banking.main;
import java.util.Scanner;
import com.cg.banking.util.BankingDB;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
public class MainClass {
	public static void main(String[] args)
	{
		Scanner scan=new Scanner(System.in);
		BankingServicesImpl bankingService=new BankingServicesImpl();
		for(int i=0;i<4;i++)
		{
		System.out.println("Enter your choice : ");
		System.out.println("Press 1 to open new account \n Press 2 to deposit money in your account"
				+ "\n Press 3 to withdraw money frm your account \nPress 4 to transfer funds to another account"
				+ " \nPress 5 to get your account details");
		int choice=scan.nextInt();
		switch (choice)
		{
		case 1:
		{
		System.out.println("Enter type of account (Savings /Current:)");
		String accountType=scan.next();
		System.out.println("Enter initial balance: ");
		float initialBalance=scan.nextFloat();
		System.out.println(bankingService.openAccount(accountType,initialBalance));
		break;
		}
		case 2:
		{
			System.out.println("Enter your account number:");
			long accNumber=scan.nextLong();
			System.out.println("Enter amount to deposit: ");
			float amt=scan.nextFloat();
			System.out.println(bankingService.depositAmount(accNumber, amt));
			break;
		}
		case 3:
		{
			System.out.println("Enter your account number:");
			long accNumber=scan.nextLong();
			System.out.println("Enter amount to withdraw: ");
			float amt=scan.nextFloat();
			System.out.println("Enter pin: ");
			int pinNumber=scan.nextInt();
			System.out.println(bankingService.withdrawAmount(accNumber, amt,pinNumber));
			break;
		}
		case 4:
		{
			System.out.println("Enter your account number: ");
			long fromAcc=scan.nextLong();
			System.out.println("Enter account number to deposit: ");
			long toAcc=scan.nextLong();
			System.out.println("Enter amount: ");
			float transfer=scan.nextFloat();
			System.out.println("Enter pin : ");
			int pinNumber=scan.nextInt();
			System.out.println(bankingService.fundTransfer(toAcc, fromAcc, transfer, pinNumber));
			break;
		}
		case 5:
		{
			System.out.println("Enter your account number:");
			long accNumber=scan.nextLong();
			System.out.println(bankingService.getAccountDetails(accNumber));
			break;
		}
		default:
			System.out.println("Wrong choice");
		}
		}
	}
		
	}   

			
			