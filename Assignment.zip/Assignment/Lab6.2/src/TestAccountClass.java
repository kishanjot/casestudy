import java.util.Scanner;

public class TestAccountClass {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        Person sm = new Person();
        sm.setName("Smith");
        sm.setAge(10);
        
        Person kt = new Person();
        sm.setName("Kathy");
        sm.setAge(22);
        
        Account smith = new CurrentAccount(1, 20000, sm);  // Initial Balance 20000
        Account kathy = new SavingAccount(2, 3000, kt);    // Initial Balance 3000
    
        System.out.println("smith now : "+smith.getBalance());
        System.out.println("Kathy Now : "+kathy.getBalance());
        
        smith.withdraw(11000);  // Generate Error bcz trying to withdraw more than 10000.
        kathy.withdraw(2600);   // Generate Error bcz this withdraw makes ammount less than 500 
                                                    // in kathy's account.
        
        System.out.println("smith now : "+smith.getBalance());
        System.out.println("Kathy Now : "+kathy.getBalance());
        
        
    }

}