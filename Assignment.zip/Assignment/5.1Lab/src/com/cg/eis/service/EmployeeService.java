package com.cg.eis.service;

public interface EmployeeService {
	static String serviceName="Capgemini Insurance";
	String print();
}
