import java.util.Scanner;
public class Program7 {

	public static void main(String[] args) {
	Scanner sc= new Scanner(System.in);
	
	System.out.println("Welcome to Capgemini: ");
	System.out.println(" Enter UserName: ");
	
	String un=sc.next();
	int length=un.length();
	
	String st =un.substring(un.length()-4,un.length());
	String cmp="_job";
	
	if((st.equals(cmp))&& (un.length()>=12))
	{
		System.out.println("Username Accepted");
	}
	else
	{
		System.out.println("Invalid Username");
	}
	}

}
