
public class SavingsAccount extends Account {
	final double minBal=500;

	public SavingsAccount(long accNum, double balance, Person accHolder){
		super( accNum,  balance,  accHolder);
	}
	
	@Override
	public void withdraw(double dep) {
		if((this.balance-dep) >= 500){
			this.balance-=dep;
		}
		else{
			System.out.println("Ammount cant be less than 500");
		}
	
	}
	
	

}
