public class SavingAccount extends Account{

    public SavingAccount(long accNo, double balance, Person accHolder) {
        super(accNo, balance, accHolder);
    }
    
    final double minBalanace = 500;
    
    public void withdraw(double wit){
        
        if((balance-wit) >= minBalanace){
            balance-=wit;
        }
        
        else{
            System.out.println("Balance can't be less than 500");
        }
        
    }
    

}