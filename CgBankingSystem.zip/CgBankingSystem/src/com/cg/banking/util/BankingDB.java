package com.cg.banking.util;
import com.cg.banking.beans.Account;
import java.util.HashMap;
public class BankingDB {
public static HashMap <Long ,Account> accountDB=new HashMap<>();
private static int ACCOUNT_NUMBER=35260001;
private static int ACCOUNT_PIN=1050;
private static String ACCOUNT_STATUS="ACTIVE";
public static int getPinNumber() {
	return ++ACCOUNT_PIN;
}
public static int getAccNumber() {
	return ACCOUNT_NUMBER++;
}
public static String getAccStatus() {
	return ACCOUNT_STATUS;
}
}