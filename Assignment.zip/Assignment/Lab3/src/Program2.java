import java.util.Scanner;
public class Program2 {

	public static void main(String[] args) {
		System.out.println("Enter string : ");
		Scanner sc= new Scanner(System.in);
		int f1=1;
		String str=sc.next();
		char[] chh=str.toCharArray();
		for(int i=0;i<chh.length-1;i++)
		{
			if(chh[i]<=chh[i+1])
			{
				f1=1;
				continue;
			}
			else
			{
				f1=0;
				break;
			}
		}
		if(f1==1)
		{
			System.out.println("String is in order");
		}
		else
		{
		System.out.println("String is not in order");	
		}
		
	}

}
