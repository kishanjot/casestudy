
public class Person {
	
	String FN;
    String LN;
    char g;
    int age;
    float wt;
    
    Person()
    {
    	
    }
    
    public Person(String FN, String LN, char g, int age, float wt)
    {
    	this.FN=FN;
    	this.LN=LN;
    	this.g=g;
    	this.age=age;
    	this.wt=wt;
    }
    
    public void dispInfo()
    {
    	System.out.println("First Name :" +FN);
    	System.out.println("Last Name :" +LN);
    	System.out.println("Gender :" +g);
    	System.out.println("Age :" +age);
    	System.out.println("Weight:" +wt);
    	 
    }
    

}
