
public class PersonClass {
String FirstName;
String LastName;
char Gender;
int Age;
float Weight;

PersonClass()
{
	
}

public PersonClass(String FirstName, String LastName, char Gender, int Age, float Weight)

{
this.FirstName=FirstName;
this.LastName=LastName;
this.Gender=Gender;
this.Age=Age;
this.Weight=Weight;
}

public String getFirstName() {
	return FirstName;
}

public void setFirstName(String firstName) {
	FirstName = firstName;
}

public String getLastName() {
	return LastName;
}

public void setLastName(String lastName) {
	LastName = lastName;
}

public char getGender() {
	return Gender;
}

public void setGender(char gender) {
	Gender = gender;
}

public int getAge() {
	return Age;
}

public void setAge(int age) {
	Age = age;
}

public float getWeight() {
	return Weight;
}

public void setWeight(float weight) {
	Weight = weight;
}

public void dispInfo()
{
	System.out.println("First Name :" +FirstName);
	System.out.println("Last Name :" +LastName);
	System.out.println("Gender :" +Gender);
	System.out.println("Age :" +Age);
	System.out.println("Weight:" +Weight);
	 
}


}
