import static  java.lang.Math.*;
public class TestAccount {

	public static void main(String[] args) {
		
		Person smith = new Person("Smith",21);
		Person kathy = new Person("Kathy",33);
		
		
		
		long accNum1=(long)(9874563212L+(Math.random()+1));
		Account smacc = new Account(accNum1,2000,smith);
		long accNum2=(long)(7852145200L+(Math.random()+1));
		Account ktacc = new Account(accNum2,3000,kathy);
		
		System.out.println("Smith Account Number is:"+accNum1);
		System.out.println("Smith Balance is:"+smacc.getBalance());
		System.out.println("Kathy Account Number is:"+accNum2);
		System.out.println("Kathy Balance is:"+ktacc.getBalance());
		
		smacc.deposit(2000);
		System.out.println(" After Deposition of Amount in Bank:");
		ktacc.withdraw(2000);
		
		System.out.println("Smith Updated Balance is:"+smacc.getBalance());
		System.out.println("Kathy Updated Balance is:"+ktacc.getBalance());

	}

}
