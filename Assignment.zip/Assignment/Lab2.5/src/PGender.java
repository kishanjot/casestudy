public class PGender
{
	
	private String firstname;
	private String lastname;
	private Gender gender;
	public PGender()
	{
		firstname = null;
		lastname =null;
		gender = Gender.M;
		
	}
	public PGender(String firstname, String lastname, Gender gender) 
	{
		
		this.firstname = firstname;
		this.lastname = lastname;
		this.gender = gender;
	}
	
	public void dispDetails()
	{
		System.out.println("First Name:"+firstname);
		System.out.println("Last Name:"+lastname);
		System.out.println("Gender:"+gender);
		
	}
	

}
