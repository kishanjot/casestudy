import static  java.lang.Math.*;             // (---------STATIC IMPORT METHOD------------)
class Calculator
{
	public int add( int ... nums)            //(-------------VARIABLE ARGUMENTS SYNTAX--------------)
	{
		int sum=0;
		for(int j=0;j<nums.length;j++)
		{
			sum=nums[j];
		}
		
		return sum;
	}
}
public class TestJavaFeaturesDemo {

	public static void main(String[] args) 
	{
	Calculator cc=new Calculator();
	System.out.println("Summation is: "+cc.add(90, 80));
	System.out.println("Summation is: "+cc.add(90, 80,99,88));
	
	System.out.println("PI Value :"+Math.PI);
    System.out.println("Sqrt root of 4 :"+sqrt(4));
    
    System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
    System.out.println("Enhanced                for                loop");
    int nums[]=new int [4];
    nums[0]=90;
    nums[1]=45;
    nums[2]=55;
    nums[3]=65;
    nums[4]=75;
    
    for(int temp:nums)                  //(-----------Ehnanced FOR LOOOP----------------)
    {
    	System.out.println("      "+temp);
    }
    
    
	}

}
